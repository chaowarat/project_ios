//
//  Car.m
//  CarPrice
//
//  Created by student on 7/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Car.h"

@implementation Car
@synthesize price, option, manufacture, model, year, available;

@end
