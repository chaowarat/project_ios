//
//  CarData.h
//  CarPrice
//
//  Created by student on 7/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarData : NSObject

+ (NSMutableArray *) smallPrice;
+ (NSMutableArray *) bigPrice;

@end
